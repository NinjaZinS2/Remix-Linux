#!/usr/bin/env bash
# Gera dist/Remix-<ver>-android.apk SEM Gradle e SEM Android Studio:
#   1) compila o raylib 5.5 + o Remix (comum/ + casca raylib de linux/ + android/) com o
#      clang do NDK, uma libremix.so por arquitetura (arm64-v8a e armeabi-v7a; x86_64
#      para o emulador com REMIX_ABIS="arm64-v8a x86_64");
#   2) empacota com aapt2 (manifesto + recursos + assets), zip (libs), zipalign e apksigner.
# Tudo vem de third_party/android (android/fetch-android.sh). Nada e instalado no sistema.
#   REMIX_VERSION=1.3.1 bash android/build-android.sh
#   REMIX_ABIS="arm64-v8a" bash android/build-android.sh      (mais rapido)
#   REMIX_KEYSTORE=/caminho/loja.keystore REMIX_KS_PASS=... REMIX_KEY_ALIAS=...   (assinatura de loja)
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"; cd "$ROOT"
TP="$ROOT/third_party/android"; SDK="$TP/sdk"
NDK_VER="${REMIX_ANDROID_NDK:-27.2.12479018}"; BUILD_TOOLS="${REMIX_ANDROID_BUILD_TOOLS:-34.0.0}"; PLATFORM="${REMIX_ANDROID_PLATFORM:-android-34}"
NDK="$SDK/ndk/$NDK_VER"; BT="$SDK/build-tools/$BUILD_TOOLS"; JAR="$SDK/platforms/$PLATFORM/android.jar"
[ -d "$NDK" ] && [ -d "$BT" ] && [ -f "$JAR" ] || { echo "[android] toolchain incompleto: rode bash android/fetch-android.sh"; exit 1; }
VER="${REMIX_VERSION:-1.4.0}"
VCODE="$(echo "$VER" | awk -F. '{printf "%d%02d%02d", $1, $2, $3}')"   # 1.3.1 -> 10301
API=24                                       # Android 7.0+ (raylib pede >= 21; 24 evita gambiarra na libc)
ABIS="${REMIX_ABIS:-arm64-v8a armeabi-v7a}"
TC="$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin"
RL="$ROOT/third_party/raylib-5.5/src"
GLUE="$NDK/sources/android/native_app_glue"
B="$ROOT/build/android"; APKDIR="$B/apk"; rm -rf "$APKDIR"; mkdir -p "$APKDIR/lib" "$ROOT/dist"

for ABI in $ABIS; do
  case "$ABI" in
    arm64-v8a)   TRIPLE=aarch64-linux-android;   ARCHF="-march=armv8-a" ;;
    armeabi-v7a) TRIPLE=armv7a-linux-androideabi; ARCHF="-march=armv7-a -mfloat-abi=softfp -mfpu=vfpv3-d16 -mthumb" ;;
    x86_64)      TRIPLE=x86_64-linux-android;     ARCHF="" ;;
    x86)         TRIPLE=i686-linux-android;       ARCHF="" ;;
    *) echo "[android] abi desconhecida: $ABI"; exit 1 ;;
  esac
  CC="$TC/${TRIPLE}${API}-clang"; CXX="$TC/${TRIPLE}${API}-clang++"
  OUT="$B/$ABI"; mkdir -p "$OUT"
  # Flags iguais as do Makefile do raylib para PLATFORM_ANDROID (GLES 2.0).
  CF="-O2 -fPIC -ffunction-sections -funwind-tables -fstack-protector-strong -no-canonical-prefixes -Wa,--noexecstack -Wformat -Werror=format-security \
      -D__ANDROID__ -DPLATFORM_ANDROID -DGRAPHICS_API_OPENGL_ES2 -DANDROID_API_VERSION=$API \
      -DSUPPORT_FILEFORMAT_JPG=1 -DSUPPORT_FILEFORMAT_BMP=1 -D_GNU_SOURCE -I$RL -I$RL/external -I$GLUE $ARCHF"
  echo "[android] $ABI: raylib"
  for f in rcore rshapes rtextures rtext utils; do "$CC" $CF -std=gnu99 -w -c "$RL/$f.c" -o "$OUT/$f.o"; done
  "$CC" $CF -std=gnu99 -w -c "$GLUE/android_native_app_glue.c" -o "$OUT/glue.o"
  echo "[android] $ABI: audio (miniaudio: AAudio/OpenSL) e Remix"
  "$CC" $CF -w -c -I"$ROOT/comum" comum/audio_backend.c -o "$OUT/audio_backend.o"
  "$CXX" $CF -std=gnu++20 -w -I"$ROOT/comum" -I"$ROOT/linux" -I"$ROOT/android" -c android/main_android.cpp -o "$OUT/main.o"
  # -u ANativeActivity_onCreate: mantem o ponto de entrada do native_app_glue na .so
  # max-page-size=16384: Android 15+ em aparelhos com pagina de 16 KB
  "$CXX" -shared -o "$OUT/libremix.so" "$OUT"/*.o \
     -u ANativeActivity_onCreate -Wl,-soname,libremix.so -Wl,--gc-sections -Wl,-z,max-page-size=16384 \
     -static-libstdc++ -llog -landroid -lEGL -lGLESv2 -lOpenSLES -ldl -lm
  mkdir -p "$APKDIR/lib/$ABI"; cp "$OUT/libremix.so" "$APKDIR/lib/$ABI/"
  "$TC/llvm-strip" --strip-unneeded "$APKDIR/lib/$ABI/libremix.so"
  cp "$OUT/libremix.so" "$B/libremix-$ABI-sym.so"    # com simbolos: ndk-stack / addr2line dos crashes
done

# ---- assets (fontes, marca, temas): vao dentro do APK; a casca copia para a pasta interna no 1o uso
ASSETS="$B/assets"; rm -rf "$ASSETS"; mkdir -p "$ASSETS/assets"
cp -a assets/branding assets/fonts assets/themes "$ASSETS/assets/"
rm -f "$ASSETS/assets/branding/app.ico"
for f in "$ASSETS"/assets/themes/*.ini; do tr -d '\r' < "$f" > "$f.n" && mv "$f.n" "$f"; done

# ---- recursos: nome do app + icone (os PNGs de linux/icons viram mipmaps)
RES="$B/res"; rm -rf "$RES"; mkdir -p "$RES/values"
cp android/res/values/strings.xml "$RES/values/"
for m in mdpi:48x48 hdpi:64x64 xhdpi:128x128 xxhdpi:128x128 xxxhdpi:256x256; do
  d="${m%%:*}"; s="${m##*:}"; mkdir -p "$RES/mipmap-$d"; cp "linux/icons/$s/remix.png" "$RES/mipmap-$d/ic_launcher.png"
done
sed -e "s/@VCODE@/$VCODE/" -e "s/@VER@/$VER/" android/AndroidManifest.xml > "$B/AndroidManifest.xml"

# ---- APK: aapt2 (manifesto + res + assets) -> libs -> zipalign -> apksigner
echo "[android] empacotando"
rm -f "$B/res.zip"; "$BT/aapt2" compile --dir "$RES" -o "$B/res.zip"
"$BT/aapt2" link -o "$B/unaligned.apk" --manifest "$B/AndroidManifest.xml" -I "$JAR" -A "$ASSETS/assets" \
   --min-sdk-version "$API" --target-sdk-version 34 --version-code "$VCODE" --version-name "$VER" "$B/res.zip"
(cd "$APKDIR" && zip -q -r "$B/unaligned.apk" lib)          # lib/<abi>/libremix.so
rm -f "$B/aligned.apk"; "$BT/zipalign" -f -p 4 "$B/unaligned.apk" "$B/aligned.apk"
KS="${REMIX_KEYSTORE:-$TP/debug.keystore}"; KSP="${REMIX_KS_PASS:-android}"; ALIAS="${REMIX_KEY_ALIAS:-remix}"
OUTAPK="$ROOT/dist/Remix-$VER-android.apk"
"$BT/apksigner" sign --ks "$KS" --ks-pass "pass:$KSP" --key-pass "pass:$KSP" --ks-key-alias "$ALIAS" --out "$OUTAPK" "$B/aligned.apk"
"$BT/apksigner" verify "$OUTAPK"
echo "[android] ok -> $OUTAPK ($(du -h "$OUTAPK" | cut -f1))"
echo "[android] instalar: $SDK/platform-tools/adb install -r \"$OUTAPK\"    log: adb logcat -s remix raylib"
