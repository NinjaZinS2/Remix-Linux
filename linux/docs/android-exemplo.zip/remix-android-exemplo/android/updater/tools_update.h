#pragma once
// Aviso de versao nova do APP (ESQUELETO, C++).
//
// Regra do projeto: o Remix nao instala, nao baixa e nao atualiza ferramenta de
// terceiros. O que fala com fonte externa e um programa de linha de comando que
// a PESSOA instalou e apontou nas configuracoes (ver src/core/fonte_externa.h).
// Este arquivo faz uma coisa so: olhar se saiu versao nova do proprio Remix e
// avisar, abrindo a pagina de releases. Quem baixa e instala e a pessoa.
//
// Usa sys::HttpGet (no Android: HttpURLConnection por JNI, a implementar em
// sys_android.h). Fonte fixa e HTTPS; nunca uma URL vinda de fora.
#include "platform.h"
#include "config.h"
#include <string>
#include <functional>

namespace appup {

static const char* REPO = "NinjaZinS2/Remix-Linux";
static const char* PAGINA = "https://github.com/NinjaZinS2/Remix-Linux/releases/latest";

inline std::wstring StampPath() { return Config::Join(Config::BaseDir(), L"atualizacoes.ini"); }

// Versao mais nova publicada: le "tag_name" do JSON de releases/latest.
inline std::string UltimaVersao(std::function<std::string(const std::string&)> httpGet) {
    std::string j = httpGet(std::string("https://api.github.com/repos/") + REPO + "/releases/latest");
    size_t p = j.find("\"tag_name\""); if (p == std::string::npos) return "";
    p = j.find('"', j.find(':', p) + 1); size_t e = j.find('"', p + 1);
    return (p == std::string::npos || e == std::string::npos) ? "" : j.substr(p + 1, e - p - 1);
}

// Checa no maximo 1x por dia (carimbo em atualizacoes.ini). Devolve a versao nova
// (vazio = nada novo ou ja checou hoje). Nunca baixa nada, nunca bloqueia o app.
inline std::string Checar(std::function<std::string(const std::string&)> httpGet,
                          const std::string& versaoAtual, long long agoraSeg, long long ultimaSeg) {
    if (agoraSeg - ultimaSeg < 24 * 3600) return "";
    std::string nova = UltimaVersao(httpGet);
    if (nova.empty()) return "";
    if (!nova.empty() && nova[0] == 'v') nova.erase(0, 1);
    return nova == versaoAtual ? "" : nova;
}

}   // namespace appup
