#pragma once
// Atualizador de ferramentas de runtime (ESQUELETO, C++). Regra do projeto: o que
// fala com servico de fora (yt-dlp, Deno, cloudflared, o proprio app) se atualiza
// sozinho, sem esperar versao nova do app. O toolchain de build NAO passa por aqui.
//
// Usa sys::HttpGet (no Android: HttpURLConnection por JNI, a implementar em
// sys_android.h) e a pasta de ferramentas do app. Fontes fixas e HTTPS: so os
// releases oficiais no GitHub; nunca uma URL vinda de fora.
#include "platform.h"
#include "config.h"
#include <string>
#include <functional>

namespace toolsup {

struct Fonte { const char* nome; const char* repo; const char* asset; };   // asset = nome do arquivo no release
// Ajuste "asset" para a arquitetura do aparelho (arm64-v8a: aarch64; armeabi-v7a: armv7l).
static const Fonte FONTES[] = {
    { "yt-dlp",      "yt-dlp/yt-dlp",          "yt-dlp_linux_aarch64" },   // so faz sentido com Python embutido (youtubedl-android) ou no PC
    { "cloudflared", "cloudflare/cloudflared", "cloudflared-linux-arm64" },
    { "remix",       "EchoGroupStudio/Remix",  "" },                         // app: so avisa (abre a pagina)
};

inline std::wstring ToolsDir() { return Config::Join(Config::AssetDir(), L"tools"); }
inline std::wstring StampPath() { return Config::Join(Config::BaseDir(), L"atualizacoes.ini"); }

// Versao mais nova publicada: le "tag_name" do JSON de releases/latest.
inline std::string UltimaVersao(const char* repo, std::function<std::string(const std::string&)> httpGet) {
    std::string j = httpGet(std::string("https://api.github.com/repos/") + repo + "/releases/latest");
    size_t p = j.find("\"tag_name\""); if (p == std::string::npos) return "";
    p = j.find('"', j.find(':', p) + 1); size_t e = j.find('"', p + 1);
    return (p == std::string::npos || e == std::string::npos) ? "" : j.substr(p + 1, e - p - 1);
}
// Baixa para <tools>/<nome>.part, confere o tamanho, troca por rename atomico e guarda
// a versao anterior como <nome>.antigo (para voltar se a nova nao abrir).
inline bool BaixarETrocar(const std::string& nome, const std::string& url, std::function<std::string(const std::string&)> httpGet) {
    std::string bytes = httpGet(url);
    if (bytes.size() < 100 * 1024) return false;   // download quebrado
    namespace fs = std::filesystem; std::error_code ec;
    fs::path dir(WideToUtf8(ToolsDir())); fs::create_directories(dir, ec);
    fs::path part = dir / (nome + ".part"), atual = dir / nome, antigo = dir / (nome + ".antigo");
    FILE* f = fopen(part.string().c_str(), "wb"); if (!f) return false;
    fwrite(bytes.data(), 1, bytes.size(), f); fclose(f);
    fs::remove(antigo, ec); if (fs::exists(atual, ec)) fs::rename(atual, antigo, ec);
    fs::rename(part, atual, ec); if (ec) { fs::rename(antigo, atual, ec); return false; }
#ifndef _WIN32
    chmod(atual.string().c_str(), 0755);
#endif
    return true;
}
// Chame ao abrir (no maximo 1x por dia) E quando uma ferramenta falhar ("atualiza e tenta
// de novo uma vez"). Nunca bloqueia a UI: rode numa thread.
inline void ChecarTudo(std::function<std::string(const std::string&)> httpGet, std::function<void(const std::wstring&)> avisar) {
    for (const Fonte& f : FONTES) {
        std::string v = UltimaVersao(f.repo, httpGet); if (v.empty()) continue;
        if (std::string(f.nome) == "remix") { avisar(L"Tem Remix novo (" + Utf8ToWide(v) + L"): abra a pagina de download."); continue; }
        // TODO: comparar com a versao instalada (--version) antes de baixar
        std::string url = std::string("https://github.com/") + f.repo + "/releases/latest/download/" + f.asset;
        if (BaixarETrocar(f.nome, url, httpGet)) avisar(Utf8ToWide(std::string(f.nome) + " atualizado para " + v));
    }
}

} // namespace toolsup
