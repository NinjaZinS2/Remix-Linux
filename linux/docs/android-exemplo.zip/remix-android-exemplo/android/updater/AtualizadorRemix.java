// ESQUELETO (Java, sem AndroidX, sem Gradle): compile com
//   javac -source 17 -target 17 -bootclasspath $SDK/platforms/android-34/android.jar -d build/classes android/updater/*.java
//   $BT/d8 --output build/dex build/classes/**/*.class
// e no manifesto troque android:hasCode="false" por "true". Usa so a plataforma:
// HttpURLConnection para ler releases/latest do GitHub e baixar o asset.
package com.echogroupstudio.remix;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public final class AtualizadorRemix {
    // yt-dlp de verdade no Android = youtubedl-android (Python embutido):
    //   YoutubeDL.getInstance().updateYoutubeDL(ctx)   -> atualiza o yt-dlp por dentro do app
    // Este arquivo cobre o resto: cloudflared e o aviso de versao nova do app.
    public static String ultimaVersao(String repo) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/releases/latest").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(8000); c.setRequestProperty("Accept", "application/vnd.github+json");
        try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
            StringBuilder sb = new StringBuilder(); String ln; while ((ln = r.readLine()) != null) sb.append(ln);
            String j = sb.toString(); int p = j.indexOf("\"tag_name\""); if (p < 0) return null;
            p = j.indexOf('"', j.indexOf(':', p) + 1); int e = j.indexOf('"', p + 1); return j.substring(p + 1, e);
        } finally { c.disconnect(); }
    }
    // baixa em .part e troca por rename (atomico); guarda .antigo para voltar
    public static boolean baixarETrocar(File dir, String nome, String url) throws IOException {
        File part = new File(dir, nome + ".part"), atual = new File(dir, nome), antigo = new File(dir, nome + ".antigo");
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection(); c.setConnectTimeout(8000); c.setReadTimeout(30000);
        try (InputStream in = c.getInputStream(); OutputStream out = new FileOutputStream(part)) {
            byte[] b = new byte[65536]; int n; long total = 0; while ((n = in.read(b)) > 0) { out.write(b, 0, n); total += n; }
            if (total < 100 * 1024) { part.delete(); return false; }
        } finally { c.disconnect(); }
        antigo.delete(); if (atual.exists()) atual.renameTo(antigo);
        boolean ok = part.renameTo(atual); if (ok) atual.setExecutable(true, true); else antigo.renameTo(atual);
        return ok;
    }
    // app novo: sem loja e sem FileProvider, o caminho sem codigo e abrir a pagina de download
    public static void abrirPaginaDoApp(Context ctx) {
        ctx.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/EchoGroupStudio/Remix/releases/latest")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
    }
}
