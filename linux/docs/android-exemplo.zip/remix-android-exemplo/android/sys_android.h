#pragma once
// Casca Android: a "camada de sistema" com a MESMA API sys:: que linux/sys_linux.h,
// so que sem zenity/kdialog, sem inotify, sem socket de instancia unica e sem libcurl.
// linux/app_state.h inclui este arquivo quando __ANDROID__ esta definido.
//
// ESQUELETO: compila contra o NDK (android/build-android.sh). O que esta marcado
// "TODO" ainda nao faz nada; o app abre e toca musica sem eles.
#include "platform.h"
#include "config.h"
#include <string>
#include <deque>
#include <mutex>
#include <thread>
#include <atomic>
#include <filesystem>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <android/log.h>
#include <android/asset_manager.h>
#include <android/native_activity.h>
#include <android/configuration.h>
#include <android_native_app_glue.h>
#include <jni.h>

// raylib expoe o android_app (internalDataPath, assetManager, activity, config)
extern "C" struct android_app* GetAndroidApp(void);

namespace sys {

// ---- fila de eventos das threads para a UI (igual ao Linux) --------------
struct Ev { int type = 0; std::wstring s; int n = 0; };
inline std::mutex& EvMutex() { static std::mutex m; return m; }
inline std::deque<Ev>& EvQueue() { static std::deque<Ev>* q = new std::deque<Ev>(); return *q; }
inline void Post(int type, std::wstring s = L"", int n = 0) { std::lock_guard<std::mutex> lk(EvMutex()); EvQueue().push_back({ type, std::move(s), n }); }
inline bool Poll(Ev& out) { std::lock_guard<std::mutex> lk(EvMutex()); if (EvQueue().empty()) return false; out = std::move(EvQueue().front()); EvQueue().pop_front(); return true; }

inline void Log(const char* msg) { __android_log_print(ANDROID_LOG_INFO, "remix", "%s", msg); }

// ---- utilidades de shell (no Android nao ha shell util para o app) --------
inline std::string ShQuote(const std::string& s) { return "'" + s + "'"; }
inline bool HaveCmd(const char*) { return false; }
inline std::string RunCapture(const std::string&) { return ""; }

// ---- dialogos de pasta/imagem: nao existem (fase 2: SAF via JNI) ----------
enum DialogKind { DLG_FOLDER, DLG_IMAGE, DLG_AUDIO_MULTI };
inline bool HasDialogTool() { return false; }
// Responde "cancelado" (s vazio) na hora, para a UI nao ficar esperando.
inline void PickAsync(DialogKind, const std::wstring&, int evType, int n = 0) { Post(evType, L"", n); }

// ---- monitor de pasta: no Android a biblioteca e relida ao voltar para o app ----
struct FolderWatch {
    std::atomic<bool> stop{ true };
    std::atomic<unsigned long long> lastChangeMs{ 0 };
    std::atomic<int> pending{ 0 };
    void Start(const std::wstring&) {}   // TODO: FileObserver via JNI, se valer a pena
    void Stop() {}
};

// ---- instancia unica / IPC: o Android ja garante uma Activity so ----------
inline bool AcquireSingleInstance() { return true; }
inline bool SendToExisting(const std::wstring&) { return false; }
inline void StartIpcServer(int) {}
inline void CleanupIpc() {}

// ---- HTTP: TODO (java.net.HttpURLConnection via JNI). Sem isso a busca online e
// as capas da internet ficam desligadas; o resto do app funciona. ---------------
inline bool HttpAvailable() { return false; }
inline std::string HttpGet(const std::string&, std::string* contentType = nullptr, long* status = nullptr) { if (contentType) contentType->clear(); if (status) *status = 0; return ""; }

// ---- arquivos temporarios / conversao ---------------------------------------
inline std::wstring TempDir() { return Utf8ToWide(std::string(GetAndroidApp()->activity->internalDataPath) + "/cache"); }
inline bool WriteFileBytes(const std::wstring& path, const std::string& data) {
    FILE* f = fopen(WideToUtf8(path).c_str(), "wb"); if (!f) return false;
    bool ok = fwrite(data.data(), 1, data.size(), f) == data.size(); fclose(f); return ok;
}
inline void InitProcess() {}
inline bool HaveFfmpeg() { return false; }                 // sem ffmpeg: so mp3/ogg/wav/flac nativos
inline std::wstring TranscodeToWav(const std::wstring&) { return L""; }
inline void CleanupCache(int maxAgeHours) {
    namespace fs = std::filesystem; std::error_code ec;
    fs::path dir(WideToUtf8(TempDir())); if (!fs::exists(dir, ec)) return;
    auto now = fs::file_time_type::clock::now();
    for (auto& e : fs::directory_iterator(dir, ec)) {
        if (!e.is_regular_file(ec)) continue;
        auto age = std::chrono::duration_cast<std::chrono::hours>(now - e.last_write_time(ec)).count();
        if (age > maxAgeHours) fs::remove(e.path(), ec);
    }
}

// ---- Android: assets do APK -> pasta interna (fontes, marca, temas) ----------
// O nucleo le os assets pelo sistema de arquivos (Config::AssetDir), entao no
// primeiro uso (ou quando a versao muda) copiamos tudo do APK para
// <internalDataPath>/assets e apontamos REMIX_ASSETS para la.
inline void CopyAssetDir(AAssetManager* am, const std::string& sub, const std::string& dstRoot) {
    AAssetDir* d = AAssetManager_openDir(am, sub.c_str()); if (!d) return;
    std::filesystem::create_directories(dstRoot + "/" + sub);
    while (const char* name = AAssetDir_getNextFileName(d)) {
        std::string rel = sub + "/" + name;
        AAsset* a = AAssetManager_open(am, rel.c_str(), AASSET_MODE_STREAMING); if (!a) continue;
        FILE* f = fopen((dstRoot + "/" + rel).c_str(), "wb");
        if (f) { char buf[65536]; int n; while ((n = AAsset_read(a, buf, sizeof buf)) > 0) fwrite(buf, 1, (size_t)n, f); fclose(f); }
        AAsset_close(a);
    }
    AAssetDir_close(d);
}
inline std::string ExtractAssets(const char* versao) {
    android_app* app = GetAndroidApp();
    std::string root = std::string(app->activity->internalDataPath) + "/assets";
    std::string marker = root + "/.versao";
    { FILE* f = fopen(marker.c_str(), "rb"); if (f) { char v[64] = { 0 }; size_t n = fread(v, 1, 63, f); fclose(f); v[n] = 0; if (std::string(v) == versao) return root; } }
    for (const char* sub : { "branding", "fonts", "themes" }) CopyAssetDir(app->activity->assetManager, sub, root);
    if (FILE* f = fopen(marker.c_str(), "wb")) { fputs(versao, f); fclose(f); }
    return root;
}

// ---- permissao de ler as musicas (Android 13+: READ_MEDIA_AUDIO) ------------
// Feito por JNI direto na NativeActivity: sem classe Java, sem AndroidX.
inline bool HasPermission(const char* perm) {
    android_app* app = GetAndroidApp(); JNIEnv* env = nullptr;
    app->activity->vm->AttachCurrentThread(&env, nullptr);
    jobject act = app->activity->clazz;
    jclass cls = env->GetObjectClass(act);
    jmethodID m = env->GetMethodID(cls, "checkSelfPermission", "(Ljava/lang/String;)I");
    jstring js = env->NewStringUTF(perm);
    int r = env->CallIntMethod(act, m, js);
    env->DeleteLocalRef(js); env->DeleteLocalRef(cls);
    app->activity->vm->DetachCurrentThread();
    return r == 0;   // PackageManager.PERMISSION_GRANTED
}
inline void RequestPermission(const char* perm) {
    android_app* app = GetAndroidApp(); JNIEnv* env = nullptr;
    app->activity->vm->AttachCurrentThread(&env, nullptr);
    jobject act = app->activity->clazz;
    jclass cls = env->GetObjectClass(act);
    jmethodID m = env->GetMethodID(cls, "requestPermissions", "([Ljava/lang/String;I)V");
    jobjectArray arr = env->NewObjectArray(1, env->FindClass("java/lang/String"), env->NewStringUTF(perm));
    env->CallVoidMethod(act, m, arr, 1);
    env->DeleteLocalRef(arr); env->DeleteLocalRef(cls);
    app->activity->vm->DetachCurrentThread();
}
inline const char* AudioPermissionName() {
    return AConfiguration_getSdkVersion(GetAndroidApp()->config) >= 33 ? "android.permission.READ_MEDIA_AUDIO" : "android.permission.READ_EXTERNAL_STORAGE";
}

// ---- densidade da tela -> escala da interface (160 dpi = 1x) ----------------
inline float ScreenDensityScale() {
    int d = AConfiguration_getDensity(GetAndroidApp()->config);
    if (d <= 0) return 2.f;
    float s = d / 160.f; if (s < 1.f) s = 1.f; if (s > 4.f) s = 4.f; return s;
}

} // namespace sys
